#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rebrand_ip.py — 把一套「小黑配图」skill 机械改造成你自己的视觉 IP。

只做可机械替换的部分（名字、slug、路径、目录名、文件重命名）。
角色外形描述（外形/性格/动作库）属于人工内容，脚本不碰，由 references/<slug>-ip.md 单独维护。

用法：
    python3 tools/rebrand_ip.py \
        --src ian-xiaohei-illustrations \
        --dst xiaofu-illustrations \
        --name 小福 --slug xiaofu --slug-cap Xiaofu \
        --keep-examples      # 保留旧示例图（默认会清空 dst 的 assets/examples/）
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys

TEXT_EXT = {".md", ".yaml", ".yml", ".txt", ".json", ".jsonc", ".py", ".html"}


def build_pairs(name: str, slug: str, slug_cap: str, old_name: str, old_slug: str, old_slug_cap: str):
    """按「长→短」排序，避免子串先被替换掉。"""
    pairs = [
        # 完整仓库/Skill 名
        (f"ian-{old_slug}-illustrations", f"{slug}-illustrations"),
        (f"Ian {old_name}怪诞正文配图", f"{name}怪诞正文配图"),
        (f"Ian {old_name}配图", f"{name}配图"),
        (f"Ian {old_name} Illustrations", f"{name} Illustrations"),
        (f"Ian {old_name} 配图", f"{name} 配图"),
        # 角色名
        (old_name, name),
        # slug（小写）
        (old_slug, slug),
        # slug（首字母大写）
        (old_slug_cap, slug_cap),
    ]
    return sorted(dict(pairs).items(), key=lambda kv: len(kv[0]), reverse=True)


def replace_text(s: str, pairs) -> str:
    for old, new in pairs:
        s = s.replace(old, new)
    return s


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default="ian-xiaohei-illustrations")
    ap.add_argument("--dst", default="xiaofu-illustrations")
    ap.add_argument("--name", default="小福", help="你的 IP 中文名")
    ap.add_argument("--slug", default="xiaofu", help="英文字母小写 slug")
    ap.add_argument("--slug-cap", default="Xiaofu")
    ap.add_argument("--old-name", default="小黑")
    ap.add_argument("--old-slug", default="xiaohei")
    ap.add_argument("--old-slug-cap", default="Xiaohei")
    ap.add_argument("--keep-examples", action="store_true",
                    help="保留旧示例图（默认删除 dst 里的 assets/examples/*.png，等待重画）")
    args = ap.parse_args()

    src, dst = args.src, args.dst
    if not os.path.isdir(src):
        print(f"× 找不到源目录 {src}", file=sys.stderr)
        return 1
    if os.path.exists(dst):
        print(f"× {dst} 已存在，先删掉或换个 --dst", file=sys.stderr)
        return 1

    pairs = build_pairs(args.name, args.slug, args.slug_cap,
                        args.old_name, args.old_slug, args.old_slug_cap)

    shutil.copytree(src, dst)
    changed_files, renamed = 0, []

    # 1) 文本替换
    for root, dirs, files in os.walk(dst):
        for f in files:
            p = os.path.join(root, f)
            if os.path.splitext(f)[1].lower() in TEXT_EXT:
                raw = open(p, encoding="utf-8").read()
                new = replace_text(raw, pairs)
                if new != raw:
                    open(p, "w", encoding="utf-8").write(new)
                    changed_files += 1

    # 2) 文件名替换（如 references/xiaohei-ip.md）
    for root, dirs, files in os.walk(dst, topdown=False):
        for f in files:
            new_f = replace_text(f, pairs)
            if new_f != f:
                os.rename(os.path.join(root, f), os.path.join(root, new_f))
                renamed.append(f"{f} -> {new_f}")

    # 3) 旧示例图处理
    examples = os.path.join(dst, "assets", "examples")
    removed = 0
    if not args.keep_examples and os.path.isdir(examples):
        for f in os.listdir(examples):
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
                os.remove(os.path.join(examples, f))
                removed += 1

    # 4) 残留检查
    leftovers = []
    for root, dirs, files in os.walk(dst):
        for f in files:
            p = os.path.join(root, f)
            if os.path.splitext(f)[1].lower() not in TEXT_EXT:
                continue
            for kw in (args.old_name, args.old_slug, args.old_slug_cap):
                n = open(p, encoding="utf-8").read().count(kw)
                if n:
                    leftovers.append((p, kw, n))

    print(f"✓ 已生成 {dst}/")
    print(f"  文本改写文件：{changed_files}")
    print(f"  重命名文件：{renamed or '无'}")
    print(f"  清理旧示例图：{removed} 张")
    if leftovers:
        print("  ⚠ 仍有旧 IP 残留（多半是署名段落，属预期）：")
        for p, kw, n in leftovers:
            print(f"    {p}  「{kw}」×{n}")
    else:
        print("  残留检查：干净")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
