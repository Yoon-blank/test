# 生图提示词模板

每张图单独生成。根据正文内容替换变量，不要把多张图拼在一起。

```text
Generate one standalone 16:9 horizontal Chinese article illustration.

Visual DNA:
Pure white background. Minimalist black hand-drawn line art. Slightly wobbly pen lines. Lots of empty white space. Sparse red/orange/blue handwritten Chinese annotations. Clean absurd product-sketch feeling. No gradients, no shadows, no paper texture, no complex background, no commercial vector style, no PPT infographic look, no cute mascot poster, no children's illustration, no realistic UI.

IDENTITY LOCK — reference image #1 is the CANONICAL character (image #2 shows it in a full scene). It must be the EXACT SAME CAT, only in a different pose and expression. If any wording conflicts with the reference images, THE REFERENCE IMAGES WIN — in every respect, including the face and the mouth.

小福 (Xiaofu): a slim grey tabby cat standing UPRIGHT on its hind legs, front paws held together in front of its chest. Head height about 1/4 of standing height; head width about the same as the torso width (slim, NOT chibi). Two triangular ears. A tiny M mark of two dark strokes on the forehead. Two small calm dark oval eyes with NO highlight — deadpan but NOT sad; do NOT droop the outer corners. A SMALL MOUTH WITH THE CORNERS GENTLY LIFTED — a quiet, subtly sweet little smile; never a downturned bitter frown. A warm cream patch from chin down to the chest. Light warm-grey base (#DED9D5) with sparse mid-grey tabby strokes (#969691): 4-5 short arcs on the flanks and 2-3 on each leg. Near-black wobbly outline (#323232) at a consistent line weight, soft watercolor-like lines.

TAIL — critical: one PLUMP TAPERED tail, thick at the base where it leaves the lower back, rising up and slightly backward, then the top third curving FORWARD and down into a rounded cane-handle hook, ending in a BIG rounded dark-grey knob. 3-4 dark grey rings spaced along it. The tail is filled with the same warm grey as the body and outlined with the same line weight — a SOLID BODY PART, not a thin ribbon, not an empty outline loop, not a curl of string.

ABSOLUTELY FORBIDDEN: drawing a separate floating question mark, or any punctuation glyph (? ! etc.) anywhere in the image; drawing a dot or circle below the tail; drawing any detached symbol near the cat. The tail must always be attached to the cat's body.

ONLY the pose/action, the expression, the facing direction, the props and the Chinese annotations may change. 小福 must perform the core conceptual action, not decorate the scene.

HARD FAILS: sitting, crouching, or standing on all fours; a chibi or big-headed redesign; a white cat or a dark grey cat; losing the cream chest patch; losing the tail rings or the dark knob tip; a thin ribbon tail; any punctuation glyph; a different cat design from the reference; shading, gradients, fluffy fur, sparkly anime eyes, blush, eyelashes, mascot-poster style.

Theme:
{正文配图主题}

Structure type:
{结构类型：Workflow / 系统局部 / 前后对比 / 角色状态 / 概念隐喻 / 方法分层 / 地图路线 / 小漫画分镜}

Core idea:
{这张图要表达的核心意思}

Composition:
{具体画面：小福在哪里、正在做什么、主要物件是什么、信息如何流动}

Suggested elements:
{元素1} / {元素2} / {元素3} / {元素4}

Chinese handwritten labels:
{标注词1} / {标注词2} / {标注词3} / {标注词4} / {可选标注词5}

Color use:
Black for main line art and 小福. Orange for main flow/path/arrows. Red only for key warnings/problems/results. Blue only for secondary notes or feedback/system state.

Constraints:
One image explains only one core structure. Keep the main subject around 40%-60% of the canvas. Preserve at least 35% blank white space. Use at most 5-8 short handwritten Chinese labels. Do not write a title in the top-left corner. Do not write the structure type on the image. Do not make it a formal diagram, course slide, or dense explainer. Do not copy prior examples or reuse known case compositions unless explicitly requested; invent a fresh visual metaphor for this specific article. It should be clear but not instructional, interesting but not childish, strange but clean.
```

## 图像编辑提示

去掉左上角标题：

```text
Edit the provided image. Remove only the handwritten title "{要删除的文字}" and its underline from the top-left corner. Fill that area with the same clean white background, matching the surrounding blank paper. Preserve everything else exactly: characters, labels, paths, line style, composition, aspect ratio, and image quality. Do not add any new text or objects.
```

增强怪诞感：

```text
Regenerate this illustration with the same core meaning and simple layout, but make 小福 more central to the conceptual action. 小福 should be doing the strange work that explains the idea, not standing beside the diagram. Keep it clean, sparse, hand-drawn, and not cute.
```
